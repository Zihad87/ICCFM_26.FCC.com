const matches = [
  {id:1,group:"GROUP A",home:"Jhenidah Cadet College",away:"Faujdarhat Cadet College",homeShort:"JCC",awayShort:"FCC",homeScore:1,awayScore:0,status:"live",time:"2nd half · 64′",date:"Today",venue:"Main Ground"},
  {id:2,group:"GROUP B",home:"Mirzapur Cadet College",away:"Rajshahi Cadet College",homeShort:"MCC",awayShort:"RCC",homeScore:null,awayScore:null,status:"upcoming",time:"3:30 PM",date:"Today",venue:"Field 2"},
  {id:3,group:"GROUP A",home:"Rangpur Cadet College",away:"Sylhet Cadet College",homeShort:"RGC",awayShort:"SCC",homeScore:2,awayScore:2,status:"finished",time:"Full time",date:"Yesterday",venue:"Main Ground"},
  {id:4,group:"GROUP B",home:"Barishal Cadet College",away:"Pabna Cadet College",homeShort:"BCC",awayShort:"PCC",homeScore:null,awayScore:null,status:"upcoming",time:"10:00 AM",date:"Tomorrow",venue:"Field 1"},
  {id:5,group:"GROUP A",home:"Faujdarhat Cadet College",away:"Rangpur Cadet College",homeShort:"FCC",awayShort:"RGC",homeScore:1,awayScore:2,status:"finished",time:"Full time",date:"Yesterday",venue:"Field 2"},
  {id:6,group:"GROUP B",home:"Jhenidah Cadet College",away:"Pabna Cadet College",homeShort:"JCC",awayShort:"PCC",homeScore:null,awayScore:null,status:"upcoming",time:"2:00 PM",date:"Tomorrow",venue:"Main Ground"}
];
const colleges = [
  {name:"Jhenidah Cadet College",short:"JCC",p:2,w:2,d:0,l:0,gf:4,ga:1,pts:6},
  {name:"Rangpur Cadet College",short:"RGC",p:2,w:1,d:1,l:0,gf:4,ga:3,pts:4},
  {name:"Faujdarhat Cadet College",short:"FCC",p:2,w:1,d:0,l:1,gf:2,ga:2,pts:3},
  {name:"Sylhet Cadet College",short:"SCC",p:2,w:0,d:1,l:1,gf:3,ga:5,pts:1}
];
const matchGrid = document.querySelector("#matchGrid");
const fixtureList = document.querySelector("#fixtureList");
const standingsBody = document.querySelector("#standingsBody");
const matchSelect = document.querySelector("#matchSelect");
let activeFilter = "all";

function scoreText(match) {
  return match.status === "upcoming" ? "—" : `${match.homeScore} <span class="score-separator">:</span> ${match.awayScore}`;
}
function statusLabel(status) { return status === "live" ? "Live now" : status === "finished" ? "Full time" : "Upcoming"; }
function renderMatches() {
  const shown = matches.filter(m => activeFilter === "all" || m.status === activeFilter);
  matchGrid.innerHTML = shown.length ? shown.map(m => `
    <article class="match-card">
      <div class="match-card-top"><span>${m.group} · MATCH ${String(m.id).padStart(2,"0")}</span><span class="status ${m.status}">${statusLabel(m.status)}</span></div>
      <div class="teams">
        <div class="team"><span class="team-badge">${m.homeShort}</span><span class="team-name">${m.home}</span></div>
        <div class="score">${scoreText(m)}<small>${m.time}</small></div>
        <div class="team"><span class="team-badge">${m.awayShort}</span><span class="team-name">${m.away}</span></div>
      </div>
      <div class="match-card-foot"><span>${m.date}</span><strong>${m.venue}</strong></div>
    </article>`).join("") : `<p class="empty-state">No matches in this category yet.</p>`;
}
function renderFixtures() {
  fixtureList.innerHTML = matches.filter(m => m.status !== "live").slice(0,5).map(m => `
    <article class="fixture-row">
      <div class="fixture-date"><strong>${m.date}</strong>${m.group}</div>
      <div class="fixture-teams"><span class="fixture-team"><span class="fixture-crest">${m.homeShort}</span>${m.home}</span><span class="fixture-vs">${m.status === "finished" ? `${m.homeScore} – ${m.awayScore}` : "VS"}</span><span class="fixture-team"><span class="fixture-crest">${m.awayShort}</span>${m.away}</span></div>
      <div class="fixture-info"><strong>${m.status === "finished" ? "Full time" : m.time}</strong><span>${m.venue}</span></div>
    </article>`).join("");
}
function renderStandings() {
  standingsBody.innerHTML = colleges.slice().sort((a,b)=>b.pts-a.pts || (b.gf-b.ga)-(a.gf-a.ga)).map((c,i)=>`
    <tr class="${i<2?"qualified":""}"><td>${i+1}</td><td><span class="college-cell"><span class="table-crest">${c.short}</span>${c.name}</span></td><td>${c.p}</td><td>${c.gf-c.ga>0?"+":""}${c.gf-c.ga}</td><td>${c.pts}</td></tr>`).join("");
}
function renderAdminSelect() {
  matchSelect.innerHTML = matches.map(m=>`<option value="${m.id}">${m.homeShort} vs ${m.awayShort} · Match ${m.id}</option>`).join("");
}
function syncAdminForm() {
  const m = matches.find(item=>item.id===Number(matchSelect.value));
  if (!m) return;
  document.querySelector("#homeScore").value = m.homeScore ?? 0;
  document.querySelector("#awayScore").value = m.awayScore ?? 0;
  document.querySelector("#matchStatus").value = m.status;
}
document.querySelectorAll("[data-filter]").forEach(button => button.addEventListener("click",()=>{
  activeFilter = button.dataset.filter;
  document.querySelectorAll("[data-filter]").forEach(b=>{const active=b===button;b.classList.toggle("active",active);b.setAttribute("aria-pressed",String(active));});
  renderMatches();
}));
const menuToggle=document.querySelector("#menuToggle");
const nav=document.querySelector("#primaryNav");
menuToggle.addEventListener("click",()=>{
  const open=nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded",String(open));
});
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");menuToggle.setAttribute("aria-expanded","false");}));
document.querySelector("#voteForm").addEventListener("submit",event=>{
  event.preventDefault();
  const college=document.querySelector("#collegeVote").value;
  document.querySelector("#voteMessage").textContent=`Demo vote noted for ${college}. It has not been saved or submitted.`;
});
matchSelect.addEventListener("change",syncAdminForm);
document.querySelector("#scoreForm").addEventListener("submit",event=>{
  event.preventDefault();
  const m=matches.find(item=>item.id===Number(matchSelect.value));
  if(!m)return;
  m.homeScore=Number(document.querySelector("#homeScore").value);
  m.awayScore=Number(document.querySelector("#awayScore").value);
  m.status=document.querySelector("#matchStatus").value;
  m.time=m.status==="finished"?"Full time":m.status==="live"?"In progress":"Scheduled";
  renderMatches();renderFixtures();
  document.querySelector("#adminMessage").textContent="Preview updated in this page only. It will reset when you reload.";
});
renderMatches();renderFixtures();renderStandings();renderAdminSelect();syncAdminForm();
