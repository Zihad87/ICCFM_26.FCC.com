# ICCFM JCC Football Meet — Website Prototype

A responsive HTML, CSS and vanilla JavaScript prototype for a cadet-college football tournament website.

## Included
- Tournament landing page and responsive navigation
- Match center with All, Live, Upcoming and Results filters
- Sample group standings
- Fixtures and results list
- Tournament statistics section
- Fan-zone demo vote (not stored or submitted)
- Match desk demo form (updates this page only)

## Important
**All match and standings data is sample data.** The admin form updates JavaScript state in the current browser session only. It is not an authenticated admin panel, database, or real-time scoring service. Replace sample data with verified tournament data before publishing as an official scoreboard.

## Run locally
No build tools or package installation are required.

1. Download or extract this project.
2. Open `index.html` in a modern browser.

For a local development server, if Python is installed, open a terminal in this folder and run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish with GitHub Pages
1. Create a new GitHub repository (for example, `iccfm-scoring-site`).
2. Upload `index.html`, `styles.css`, `script.js`, and `README.md` to the repository root.
3. Open the repository's **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for the Pages deployment link to appear.

## Suggested next production steps
- Confirm the official list of colleges, groups, match dates and venues.
- Decide who is allowed to update official scores.
- Add a secure backend/database and authentication before treating admin updates as official.
- Connect standings and statistics to verified results.
- Test keyboard navigation, screen-reader labels and narrow mobile screens.
